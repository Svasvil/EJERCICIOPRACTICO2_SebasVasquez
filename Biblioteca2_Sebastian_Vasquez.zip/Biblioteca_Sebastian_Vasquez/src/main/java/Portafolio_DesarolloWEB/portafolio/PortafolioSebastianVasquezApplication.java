package Portafolio_DesarolloWEB.portafolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortafolioSebastianVasquezApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortafolioSebastianVasquezApplication.class, args);
	}

}
